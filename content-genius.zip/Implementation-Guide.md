# ContentFlow Implementation Guide
## Step-by-Step Tutorial to Launch Your Platform

---

## 📋 Overview
This guide will walk you through:
1. ✅ Setting up your development environment
2. ✅ Connecting to the Anthropic API
3. ✅ Building the backend
4. ✅ Setting up the database
5. ✅ Deploying to production
6. ✅ Launching your landing page

**Total time to MVP:** 2-3 weeks working part-time

---

## Step 1: Set Up Your Development Environment

### 1.1 Prerequisites
You need:
- **Git** - Version control
- **Node.js 18+** - JavaScript runtime
- **npm or yarn** - Package manager
- **PostgreSQL** - Database (or use cloud version)
- **VS Code** - Code editor (optional but recommended)

### 1.2 Install Everything

**On Mac:**
```bash
# Install Homebrew if you don't have it
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Node.js
brew install node

# Install PostgreSQL
brew install postgresql

# Verify installations
node --version    # Should be v18+
npm --version     # Should be v9+
psql --version    # Should be postgres (version number)
```

**On Windows:**
- Download Node.js from nodejs.org (includes npm)
- Download PostgreSQL from postgresql.org
- Download Git from git-scm.com

**On Linux:**
```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
nvm install 18
npm install -g npm@latest
sudo apt-get install postgresql postgresql-contrib
```

### 1.3 Create Your Project Structure

```bash
# Create main project directory
mkdir contentflow
cd contentflow

# Create frontend (React app)
npx create-react-app frontend

# Create backend directory
mkdir backend
cd backend
npm init -y

# Back to root
cd ..
```

**Your structure should look like:**
```
contentflow/
├── frontend/          (React app)
├── backend/           (Node.js API)
├── .gitignore
└── README.md
```

---

## Step 2: Set Up Anthropic API Access

### 2.1 Create Anthropic Account

1. Go to **console.anthropic.com**
2. Sign up with email
3. Verify email
4. Go to **Settings → API Keys**
5. Click **Create Key**
6. Save your key safely (you'll need it)

### 2.2 Set Up Environment Variables

**In your `backend/` directory:**

```bash
# Create .env file
touch .env

# Add this to .env (replace YOUR_KEY with actual key)
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxx
DATABASE_URL=postgresql://user:password@localhost:5432/contentflow
JWT_SECRET=your-super-secret-key-here-change-this
NODE_ENV=development
PORT=5000
```

**Add `.env` to `.gitignore`:**
```bash
# In backend/.gitignore
.env
.env.local
node_modules/
```

### 2.3 Install Anthropic SDK

**In your `backend/` directory:**

```bash
npm install @anthropic-ai/sdk dotenv express cors pg
```

This installs:
- `@anthropic-ai/sdk` - Claude API client
- `dotenv` - Environment variable loader
- `express` - Web framework
- `cors` - Cross-origin requests
- `pg` - PostgreSQL client

---

## Step 3: Build the Backend API

### 3.1 Create Basic Server

**Create `backend/server.js`:**

```javascript
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const Anthropic = require('@anthropic-ai/sdk');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Initialize Anthropic client
const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY
});

// Basic test route
app.get('/api/health', (req, res) => {
  res.json({ status: 'Server is running' });
});

// Content generation endpoint
app.post('/api/generate', async (req, res) => {
  try {
    const { contentType, userProfile } = req.body;

    // Validate inputs
    if (!contentType || !userProfile) {
      return res.status(400).json({ error: 'Missing contentType or userProfile' });
    }

    // Build prompt based on content type
    const prompts = {
      linkedin: `Generate a compelling LinkedIn post for ${userProfile.name} about their expertise.
      Expertise: ${userProfile.expertise}
      Bio: ${userProfile.bio}
      Tone: ${userProfile.tone}
      Audience: ${userProfile.audience}
      Style: ${userProfile.style}
      Make it engaging with a hook, 3-4 insights, and a CTA. Include emojis. Keep it 150-250 words.`,
      
      blog: `Generate a blog post outline for "${userProfile.expertise}" insights.
      Style: ${userProfile.style}
      Audience: ${userProfile.audience}
      Create a catchy title, compelling introduction, and 5-point outline.`,
      
      newsletter: `Generate a newsletter section for ${userProfile.name}.
      Topic: A recent insight about ${userProfile.expertise}
      Audience: ${userProfile.audience}
      Include: subject line, opening hook, 2 actionable insights, and CTA.`,
      
      video: `Generate 3 short-form video ideas for ${userProfile.name}.
      Expertise: ${userProfile.expertise}
      Style: ${userProfile.style}
      For each: Title, Hook (first 10 seconds), main talking points, ending/CTA.`,
      
      twitter: `Generate 5 tweet ideas for ${userProfile.name}.
      Expertise: ${userProfile.expertise}
      Tone: ${userProfile.tone}
      Mix of: hot takes, tips, behind-the-scenes, questions. Max 280 chars each.`
    };

    const prompt = prompts[contentType];

    if (!prompt) {
      return res.status(400).json({ error: 'Invalid contentType' });
    }

    // Call Claude API
    const message = await client.messages.create({
      model: 'claude-opus-4-20250805',
      max_tokens: 1000,
      messages: [
        {
          role: 'user',
          content: prompt
        }
      ]
    });

    // Extract response
    const content = message.content[0].type === 'text' ? message.content[0].text : '';

    res.json({
      success: true,
      contentType,
      generatedContent: content,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({
      error: 'Failed to generate content',
      details: error.message
    });
  }
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});
```

### 3.2 Test Your API

```bash
cd backend
node server.js
```

You should see: `✅ Server running on http://localhost:5000`

**Test the endpoint (in another terminal):**
```bash
curl http://localhost:5000/api/health
```

Should return: `{"status":"Server is running"}`

---

## Step 4: Set Up the Database

### 4.1 Create PostgreSQL Database

```bash
# Open PostgreSQL
psql

# Create database
CREATE DATABASE contentflow;

# Connect to it
\c contentflow

# Create tables
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255),
  name VARCHAR(255),
  expertise VARCHAR(500),
  bio TEXT,
  tone VARCHAR(50),
  audience VARCHAR(255),
  style VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE content (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  content_type VARCHAR(50),
  title VARCHAR(255),
  content TEXT,
  saved BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE subscriptions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  plan VARCHAR(50),
  stripe_customer_id VARCHAR(255),
  status VARCHAR(50),
  started_at TIMESTAMP,
  ended_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

# Verify tables were created
\dt

# Exit PostgreSQL
\q
```

### 4.2 Connect Backend to Database

**Create `backend/db.js`:**

```javascript
const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
});

module.exports = pool;
```

### 4.3 Create User Routes

**Create `backend/routes/users.js`:**

```javascript
const express = require('express');
const router = express.Router();
const pool = require('../db');

// Get user profile
router.get('/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await pool.query(
      'SELECT * FROM users WHERE id = $1',
      [userId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update user profile
router.put('/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { name, expertise, bio, tone, audience, style } = req.body;
    
    const result = await pool.query(
      `UPDATE users SET 
       name = $1, expertise = $2, bio = $3, 
       tone = $4, audience = $5, style = $6,
       updated_at = CURRENT_TIMESTAMP
       WHERE id = $7 RETURNING *`,
      [name, expertise, bio, tone, audience, style, userId]
    );
    
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
```

**Update `backend/server.js` to use routes:**

```javascript
// Add after other requires
const userRoutes = require('./routes/users');

// Add after middleware
app.use('/api/users', userRoutes);
```

---

## Step 5: Connect Frontend to Backend

### 5.1 Update Frontend to Call API

**In `frontend/src/` create `api.js`:**

```javascript
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

export const generateContent = async (contentType, userProfile) => {
  const response = await fetch(`${API_URL}/api/generate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ contentType, userProfile })
  });

  if (!response.ok) {
    throw new Error('Failed to generate content');
  }

  return response.json();
};

export const getUserProfile = async (userId) => {
  const response = await fetch(`${API_URL}/api/users/${userId}`);
  
  if (!response.ok) {
    throw new Error('Failed to fetch user profile');
  }

  return response.json();
};

export const updateUserProfile = async (userId, profile) => {
  const response = await fetch(`${API_URL}/api/users/${userId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(profile)
  });

  if (!response.ok) {
    throw new Error('Failed to update profile');
  }

  return response.json();
};
```

### 5.2 Update React Component to Use API

**In `frontend/src/` create `.env`:**

```
REACT_APP_API_URL=http://localhost:5000
```

**Update your component's `generateContent` function:**

```javascript
import { generateContent } from './api';

const generateContent = async () => {
  setLoading(true);
  
  try {
    const result = await generateContent(contentType, userProfile);
    setGeneratedContent({
      id: Date.now(),
      type: contentType,
      title: `Generated ${contentType}`,
      content: result.generatedContent,
      date: new Date().toISOString().split('T')[0],
      saved: false
    });
  } catch (error) {
    console.error('Error:', error);
    alert('Failed to generate content');
  }
  
  setLoading(false);
};
```

### 5.3 Run Both Servers

**Terminal 1 - Backend:**
```bash
cd backend
npm start
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
```

Your app should open at `http://localhost:3000`

---

## Step 6: Deploy to Production

### 6.1 Deploy Backend (Using Render)

1. Push code to GitHub
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/yourusername/contentflow.git
   git push -u origin main
   ```

2. Go to **render.com**
3. Click **New +** → **Web Service**
4. Connect your GitHub repo
5. Settings:
   - Name: `contentflow-api`
   - Runtime: `Node`
   - Build command: `npm install`
   - Start command: `node server.js`
6. Add environment variables:
   - `ANTHROPIC_API_KEY` = your key
   - `DATABASE_URL` = your PostgreSQL URL
   - `JWT_SECRET` = your secret
7. Deploy!

Your API will be at: `https://contentflow-api.onrender.com`

### 6.2 Deploy Frontend (Using Vercel)

1. Go to **vercel.com**
2. Click **Add New** → **Project**
3. Import your GitHub repo
4. Project settings:
   - Framework: `Create React App`
   - Root Directory: `./frontend`
5. Environment variables:
   - `REACT_APP_API_URL` = `https://contentflow-api.onrender.com`
6. Deploy!

Your app will be at: `https://contentflow-xxx.vercel.app`

### 6.3 Update Database

Connect your Render deployment to a managed PostgreSQL database:

1. Go to **render.com** → **PostgreSQL**
2. Create new PostgreSQL instance
3. Copy connection string
4. Add to Render Web Service environment: `DATABASE_URL`
5. Run migrations on deployed database

---

## Step 7: Launch Landing Page

### 7.1 Create Simple Landing Page

**Create `landing/index.html`:**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ContentFlow - AI Content for Authentic Creators</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
    
    .hero {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 100px 20px;
      text-align: center;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    
    h1 { font-size: 3.5rem; margin-bottom: 20px; }
    p { font-size: 1.25rem; margin-bottom: 40px; opacity: 0.9; }
    
    .cta {
      display: inline-block;
      background: white;
      color: #667eea;
      padding: 15px 40px;
      border-radius: 50px;
      font-weight: bold;
      text-decoration: none;
      transition: transform 0.3s;
    }
    
    .cta:hover { transform: scale(1.05); }
    
    .features {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 30px;
      padding: 60px 20px;
      max-width: 1200px;
      margin: 0 auto;
    }
    
    .feature {
      padding: 30px;
      border: 1px solid #ddd;
      border-radius: 10px;
      text-align: center;
    }
    
    .feature h3 { margin-bottom: 10px; }
    .feature p { color: #666; }
  </style>
</head>
<body>
  <div class="hero">
    <h1>ContentFlow</h1>
    <p>Generate 10 hours of content in 10 minutes—without losing your voice</p>
    <a href="https://app.contentflow.com" class="cta">Start Free Today</a>
  </div>
  
  <div class="features">
    <div class="feature">
      <h3>💼 LinkedIn Posts</h3>
      <p>Engaging posts that get clicks and comments</p>
    </div>
    <div class="feature">
      <h3>📝 Blog Posts</h3>
      <p>Full outlines and compelling intros</p>
    </div>
    <div class="feature">
      <h3>📧 Newsletters</h3>
      <p>Email-ready content with subject lines</p>
    </div>
    <div class="feature">
      <h3>🎬 Video Ideas</h3>
      <p>Short-form scripts and concepts</p>
    </div>
    <div class="feature">
      <h3>🔐 Your Voice</h3>
      <p>Authentic content that sounds like you</p>
    </div>
    <div class="feature">
      <h3>⚡ Save Time</h3>
      <p>60+ hours per month back in your day</p>
    </div>
  </div>
</body>
</html>
```

### 7.2 Deploy Landing Page

1. Go to **vercel.com**
2. Upload the `landing` folder
3. Custom domain: `contentflow.com` (buy on Namecheap or Route53)
4. Update DNS records

---

## Step 8: Set Up User Authentication

### 8.1 Add JWT Authentication

**In `backend/` install:**
```bash
npm install bcryptjs jsonwebtoken
```

**Create `backend/middleware/auth.js`:**

```javascript
const jwt = require('jsonwebtoken');

const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

module.exports = authenticate;
```

### 8.2 Create Sign-Up Endpoint

**Add to `backend/routes/users.js`:**

```javascript
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Sign up
router.post('/signup', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Create user
    const result = await pool.query(
      `INSERT INTO users (email, password_hash, name) 
       VALUES ($1, $2, $3) RETURNING id, email, name`,
      [email, hashedPassword, name]
    );
    
    // Create JWT token
    const token = jwt.sign(
      { userId: result.rows[0].id },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    res.json({
      user: result.rows[0],
      token
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user
    const result = await pool.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    );
    
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Check password
    const user = result.rows[0];
    const validPassword = await bcrypt.compare(password, user.password_hash);
    
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Create token
    const token = jwt.sign(
      { userId: user.id },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    res.json({
      user: { id: user.id, email: user.email, name: user.name },
      token
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
```

---

## Step 9: Add Payment Processing (Stripe)

### 9.1 Set Up Stripe

```bash
cd backend
npm install stripe
```

**Create `backend/routes/payments.js`:**

```javascript
const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const pool = require('../db');
const authenticate = require('../middleware/auth');

// Create checkout session
router.post('/checkout', authenticate, async (req, res) => {
  try {
    const { plan } = req.body;
    const userId = req.userId;
    
    const prices = {
      starter: process.env.STRIPE_STARTER_PRICE_ID,
      pro: process.env.STRIPE_PRO_PRICE_ID,
      agency: process.env.STRIPE_AGENCY_PRICE_ID
    };
    
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price: prices[plan],
        quantity: 1
      }],
      mode: 'subscription',
      success_url: `${process.env.FRONTEND_URL}/success`,
      cancel_url: `${process.env.FRONTEND_URL}/pricing`,
      client_reference_id: userId.toString()
    });
    
    res.json({ sessionId: session.id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
```

---

## Step 10: Next Steps After Launch

### Immediate (Week 1-2)
- [ ] Launch landing page
- [ ] Get 50 beta signups
- [ ] Collect feedback
- [ ] Fix bugs

### Short-term (Month 1)
- [ ] Add email notifications
- [ ] Analytics dashboard
- [ ] Content templates library
- [ ] Direct publishing to LinkedIn/Twitter

### Medium-term (Months 2-3)
- [ ] Paid ads (Google, LinkedIn)
- [ ] Affiliate program
- [ ] Content marketing
- [ ] SEO optimization

### Growth (Months 3+)
- [ ] Sales team for enterprises
- [ ] API access
- [ ] White-label version
- [ ] International expansion

---

## Troubleshooting

### Port 5000 already in use
```bash
# Kill process on port 5000
lsof -i :5000
kill -9 <PID>
```

### Database connection error
```bash
# Check PostgreSQL is running
brew services start postgresql  # Mac
psql                             # Connect to test
```

### CORS errors
Add this to `backend/server.js`:
```javascript
app.use(cors({
  origin: ['http://localhost:3000', 'https://yourdomain.com'],
  credentials: true
}));
```

### API not responding
```bash
# Check backend is running
curl http://localhost:5000/api/health
```

---

## Resources

- **Node.js Docs:** nodejs.org/docs
- **PostgreSQL Docs:** postgresql.org/docs
- **Anthropic API:** console.anthropic.com
- **Render Deployment:** render.com/docs
- **Vercel Deployment:** vercel.com/docs
- **Stripe Integration:** stripe.com/docs

---

## Summary

You now have:
1. ✅ Local development environment
2. ✅ React frontend + Node backend
3. ✅ PostgreSQL database
4. ✅ Anthropic Claude API integration
5. ✅ User authentication
6. ✅ Deployed to production
7. ✅ Landing page live

**You're ready to get your first 100 users!**

Next: Launch on Product Hunt, Hacker News, and share with your network.

Questions? Check the troubleshooting section or ask on:
- Stack Overflow
- GitHub Discussions
- Discord (React, Node.js communities)
