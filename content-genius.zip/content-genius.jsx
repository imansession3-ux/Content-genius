import React, { useState } from 'react';
import { Sparkles, Menu, X, Copy, Download } from 'lucide-react';

export default function ContentGenius() {
  const [section, setSection] = useState('setup'); // setup, generate, library
  const [profile, setProfile] = useState({
    name: '',
    expertise: '',
    voice: 'professional',
    industry: '',
    style: 'engaging'
  });

  const [contentRequest, setContentRequest] = useState({
    topic: '',
    format: 'linkedin', // linkedin, blog, video, email
    tone: 'professional',
    length: 'medium'
  });

  const [generatedContent, setGeneratedContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [contentLibrary, setContentLibrary] = useState([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [copiedId, setCopiedId] = useState(null);

  const generateContent = async () => {
    if (!profile.name || !contentRequest.topic) {
      alert('Please complete your profile and enter a topic');
      return;
    }

    setLoading(true);
    const voiceDescription = {
      professional: 'formal, authoritative, data-driven',
      conversational: 'friendly, approachable, conversational',
      witty: 'humorous, clever, with sharp wit',
      inspiring: 'motivational, uplifting, empowering',
      technical: 'detailed, precise, technical insights'
    };

    const formatInstructions = {
      linkedin: 'Format as a LinkedIn post (2-3 paragraphs, professional yet engaging). Include 2-3 relevant hashtags at the end.',
      blog: 'Format as a blog article introduction and first section (400-600 words). Include a compelling headline and subheadings.',
      video: 'Create a video script outline (3-5 minutes of speaking). Include: Hook, 3 main points, Call-to-action. Format with [SCENE] markers.',
      email: 'Write a professional email newsletter (150-250 words). Include: Subject line, engaging opening, key insight, and clear CTA.'
    };

    const prompt = `You are a content creation expert. Generate authentic, high-quality ${contentRequest.format} content.

Creator Profile:
- Name: ${profile.name}
- Expertise: ${profile.expertise}
- Industry: ${profile.industry}
- Voice/Tone: ${voiceDescription[profile.voice]}
- Style Preference: ${contentRequest.tone}

Topic: ${contentRequest.topic}

${formatInstructions[contentRequest.format]}

Generate content that sounds natural and authentic to this creator's voice. Avoid generic phrases. Make it memorable and share-worthy.`;

    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [{ role: 'user', content: prompt }]
        })
      });

      const data = await response.json();
      const content = data.content[0].text;
      setGeneratedContent(content);

      // Add to library
      const newItem = {
        id: Date.now(),
        format: contentRequest.format,
        topic: contentRequest.topic,
        content: content,
        date: new Date().toLocaleDateString()
      };
      setContentLibrary([newItem, ...contentLibrary]);

    } catch (error) {
      alert('Error generating content. Please try again.');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatBadge = (format) => {
    const badges = {
      linkedin: 'bg-blue-100 text-blue-700',
      blog: 'bg-purple-100 text-purple-700',
      video: 'bg-red-100 text-red-700',
      email: 'bg-green-100 text-green-700'
    };
    return badges[format] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-lg border-b border-slate-200 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
              Content Genius
            </h1>
          </div>

          {/* Desktop Nav */}
          <div className="hidden sm:flex gap-6">
            {['setup', 'generate', 'library'].map((item) => (
              <button
                key={item}
                onClick={() => setSection(item)}
                className={`capitalize font-medium transition-all ${
                  section === item
                    ? 'text-amber-600 border-b-2 border-amber-600'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {item}
              </button>
            ))}
          </div>

          {/* Mobile Menu */}
          <button className="sm:hidden" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {menuOpen && (
          <div className="sm:hidden bg-white border-t border-slate-200 p-4 flex flex-col gap-3">
            {['setup', 'generate', 'library'].map((item) => (
              <button
                key={item}
                onClick={() => {
                  setSection(item);
                  setMenuOpen(false);
                }}
                className={`capitalize font-medium text-left p-2 ${
                  section === item ? 'bg-amber-50 text-amber-600' : 'text-slate-600'
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        )}
      </nav>

      <div className="pt-20 pb-12 px-6">
        <div className="max-w-5xl mx-auto">
          {/* SETUP SECTION */}
          {section === 'setup' && (
            <div className="space-y-8 animate-fadeIn">
              <div>
                <h2 className="text-4xl font-bold text-slate-900 mb-3">
                  Define Your Voice
                </h2>
                <p className="text-lg text-slate-600">
                  Help us understand your unique style and expertise so we can generate authentic content.
                </p>
              </div>

              <div className="bg-white rounded-2xl shadow-lg p-8 space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-2">
                      Your Name / Brand
                    </label>
                    <input
                      type="text"
                      value={profile.name}
                      onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                      placeholder="e.g., Alex Thompson"
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-2">
                      Industry / Field
                    </label>
                    <input
                      type="text"
                      value={profile.industry}
                      onChange={(e) => setProfile({ ...profile, industry: e.target.value })}
                      placeholder="e.g., Product Management, Marketing"
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-900 mb-2">
                    Your Expertise / What You Share About
                  </label>
                  <textarea
                    value={profile.expertise}
                    onChange={(e) => setProfile({ ...profile, expertise: e.target.value })}
                    placeholder="e.g., Growth strategies, startup scaling, data-driven decision making"
                    rows="3"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none transition"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-3">
                      Communication Style
                    </label>
                    <div className="space-y-2">
                      {['professional', 'conversational', 'witty', 'inspiring', 'technical'].map((style) => (
                        <label key={style} className="flex items-center gap-3 cursor-pointer hover:bg-amber-50 p-2 rounded-lg transition">
                          <input
                            type="radio"
                            name="voice"
                            value={style}
                            checked={profile.voice === style}
                            onChange={(e) => setProfile({ ...profile, voice: e.target.value })}
                            className="w-4 h-4"
                          />
                          <span className="capitalize text-slate-700">{style}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-3">
                      Default Tone
                    </label>
                    <div className="space-y-2">
                      {['professional', 'casual', 'technical', 'storytelling', 'humorous'].map((style) => (
                        <label key={style} className="flex items-center gap-3 cursor-pointer hover:bg-amber-50 p-2 rounded-lg transition">
                          <input
                            type="radio"
                            name="style"
                            value={style}
                            checked={profile.style === style}
                            onChange={(e) => setProfile({ ...profile, style: e.target.value })}
                            className="w-4 h-4"
                          />
                          <span className="capitalize text-slate-700">{style}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-200">
                  <button
                    onClick={() => setSection('generate')}
                    className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-semibold py-3 rounded-lg transition-all transform hover:scale-105 active:scale-95"
                  >
                    Start Creating Content →
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* GENERATE SECTION */}
          {section === 'generate' && (
            <div className="space-y-8 animate-fadeIn">
              <div>
                <h2 className="text-4xl font-bold text-slate-900 mb-3">
                  Generate Content
                </h2>
                <p className="text-lg text-slate-600">
                  Tell us what you want to create, and we'll generate it in your voice.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Input Panel */}
                <div className="lg:col-span-1 bg-white rounded-2xl shadow-lg p-6 space-y-5 h-fit">
                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-2">
                      Content Topic
                    </label>
                    <input
                      type="text"
                      value={contentRequest.topic}
                      onChange={(e) => setContentRequest({ ...contentRequest, topic: e.target.value })}
                      placeholder="What do you want to write about?"
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-3">
                      Content Format
                    </label>
                    <div className="space-y-2">
                      {[
                        { id: 'linkedin', label: 'LinkedIn Post', emoji: '💼' },
                        { id: 'blog', label: 'Blog Article', emoji: '📝' },
                        { id: 'video', label: 'Video Script', emoji: '🎬' },
                        { id: 'email', label: 'Email Newsletter', emoji: '📧' }
                      ].map((fmt) => (
                        <label key={fmt.id} className="flex items-center gap-3 cursor-pointer hover:bg-amber-50 p-2 rounded-lg transition">
                          <input
                            type="radio"
                            name="format"
                            value={fmt.id}
                            checked={contentRequest.format === fmt.id}
                            onChange={(e) => setContentRequest({ ...contentRequest, format: e.target.value })}
                            className="w-4 h-4"
                          />
                          <span className="text-lg">{fmt.emoji}</span>
                          <span className="text-slate-700 font-medium">{fmt.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-3">
                      Tone Override
                    </label>
                    <select
                      value={contentRequest.tone}
                      onChange={(e) => setContentRequest({ ...contentRequest, tone: e.target.value })}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none transition"
                    >
                      {['professional', 'casual', 'technical', 'storytelling', 'humorous'].map((t) => (
                        <option key={t} value={t} className="capitalize">{t.charAt(0).toUpperCase() + t.slice(1)}</option>
                      ))}
                    </select>
                  </div>

                  <button
                    onClick={generateContent}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 disabled:from-slate-400 disabled:to-slate-400 text-white font-semibold py-3 rounded-lg transition-all transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-5 h-5" />
                    {loading ? 'Creating...' : 'Generate Content'}
                  </button>
                </div>

                {/* Output Panel */}
                <div className="lg:col-span-2">
                  {generatedContent ? (
                    <div className="bg-white rounded-2xl shadow-lg p-8 space-y-4">
                      <div className="flex items-center justify-between">
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${formatBadge(contentRequest.format)}`}>
                          {contentRequest.format.toUpperCase()}
                        </span>
                        <button
                          onClick={() => copyToClipboard(generatedContent, 'main')}
                          className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition text-sm font-medium"
                        >
                          <Copy className="w-4 h-4" />
                          {copiedId === 'main' ? 'Copied!' : 'Copy'}
                        </button>
                      </div>
                      <div className="prose prose-sm max-w-none">
                        <div className="text-slate-700 leading-relaxed whitespace-pre-wrap font-medium">
                          {generatedContent}
                        </div>
                      </div>
                      <div className="pt-4 border-t border-slate-200 flex gap-3">
                        <button
                          onClick={generateContent}
                          className="flex-1 px-4 py-2 border border-amber-500 text-amber-600 rounded-lg hover:bg-amber-50 transition font-medium"
                        >
                          Regenerate
                        </button>
                        <button
                          onClick={() => {
                            const element = document.createElement('a');
                            element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(generatedContent));
                            element.setAttribute('download', `content-${Date.now()}.txt`);
                            element.style.display = 'none';
                            document.body.appendChild(element);
                            element.click();
                            document.body.removeChild(element);
                          }}
                          className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition font-medium flex items-center justify-center gap-2"
                        >
                          <Download className="w-4 h-4" />
                          Download
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-12 text-center border-2 border-dashed border-amber-200">
                      <Sparkles className="w-12 h-12 text-amber-400 mx-auto mb-4 opacity-50" />
                      <p className="text-slate-600 text-lg">
                        Fill in your topic and click "Generate Content" to see your creation.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* LIBRARY SECTION */}
          {section === 'library' && (
            <div className="space-y-8 animate-fadeIn">
              <div>
                <h2 className="text-4xl font-bold text-slate-900 mb-3">
                  Content Library
                </h2>
                <p className="text-lg text-slate-600">
                  All your generated content in one place. Save, edit, or export.
                </p>
              </div>

              {contentLibrary.length === 0 ? (
                <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                  <p className="text-slate-600 text-lg mb-4">No content generated yet.</p>
                  <button
                    onClick={() => setSection('generate')}
                    className="inline-block bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-semibold py-3 px-6 rounded-lg transition-all"
                  >
                    Create Your First Piece →
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {contentLibrary.map((item) => (
                    <div key={item.id} className="bg-white rounded-2xl shadow-lg p-6 space-y-4 hover:shadow-xl transition-shadow">
                      <div className="flex items-center justify-between flex-wrap gap-4">
                        <div>
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${formatBadge(item.format)} mb-2`}>
                            {item.format.toUpperCase()}
                          </span>
                          <h3 className="text-lg font-bold text-slate-900">{item.topic}</h3>
                          <p className="text-sm text-slate-500">{item.date}</p>
                        </div>
                        <button
                          onClick={() => copyToClipboard(item.content, item.id)}
                          className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition text-sm font-medium"
                        >
                          <Copy className="w-4 h-4" />
                          {copiedId === item.id ? 'Copied!' : 'Copy'}
                        </button>
                      </div>
                      <div className="text-slate-700 leading-relaxed line-clamp-3">
                        {item.content}
                      </div>
                      <button
                        onClick={() => {
                          setContentRequest({
                            ...contentRequest,
                            topic: item.topic,
                            format: item.format
                          });
                          setGeneratedContent(item.content);
                          setSection('generate');
                        }}
                        className="text-amber-600 hover:text-amber-700 font-medium text-sm"
                      >
                        View Full & Edit →
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <style jsx>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

        * {
          font-family: 'Plus Jakarta Sans', sans-serif;
        }

        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fadeIn {
          animation: fadeIn 0.4s ease-out;
        }

        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
}
