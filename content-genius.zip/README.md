# Content Genius - AI Content Generator

An AI-powered platform that helps freelancers, consultants, and creators generate authentic content in their unique voice.

## Features

- 📝 **Multiple Content Formats**: LinkedIn posts, blog articles, video scripts, and email newsletters
- 🎯 **Authentic Voice**: Define your unique style and expertise for personalized content
- 📚 **Content Library**: Save and manage all your generated content
- ⚡ **Powered by Claude AI**: Using Anthropic's Claude for high-quality content generation
- 📱 **Responsive Design**: Works on desktop, tablet, and mobile

## Quick Start

### Prerequisites
- Node.js 16+ installed on your computer
- A Claude API key from [console.anthropic.com](https://console.anthropic.com)

### Installation

1. **Clone or download this project**

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   - Create a `.env.local` file in the root directory
   - Add your Claude API key:
   ```
   VITE_ANTHROPIC_API_KEY=sk-ant-your-key-here
   ```

4. **Run locally**
   ```bash
   npm run dev
   ```
   Open `http://localhost:5173` in your browser

5. **Build for production**
   ```bash
   npm run build
   ```

## Deployment to Vercel

1. **Push to GitHub**
   - Create a GitHub account (if you don't have one)
   - Create a new repository called `content-genius`
   - Push all files to GitHub

2. **Deploy to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Sign in with GitHub
   - Click "New Project"
   - Select your `content-genius` repository
   - Add environment variable:
     - Name: `VITE_ANTHROPIC_API_KEY`
     - Value: Your Claude API key
   - Click Deploy

Your site will be live in minutes!

## Project Structure

```
├── src/
│   ├── App.jsx           # Main component
│   ├── main.jsx          # React entry point
│   └── index.css         # Styles
├── index.html            # HTML template
├── package.json          # Dependencies
├── vite.config.js        # Vite configuration
├── tailwind.config.js    # Tailwind CSS config
└── postcss.config.js     # PostCSS config
```

## Technologies Used

- **React 18** - UI framework
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Lucide Icons** - Icons
- **Anthropic Claude API** - AI content generation

## License

MIT License - feel free to modify and use!

## Support

For issues or questions:
1. Check the Claude API documentation
2. Review your API key settings
3. Ensure all dependencies are installed correctly
