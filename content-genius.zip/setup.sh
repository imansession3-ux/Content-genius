#!/bin/bash

# ContentFlow Quick-Start Setup Script
# This script automates the initial setup

echo "🚀 ContentFlow Setup Script"
echo "=========================="
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Node.js
echo "📦 Checking Node.js..."
if ! command -v node &> /dev/null; then
    echo -e "${RED}Node.js not found. Please install it from nodejs.org${NC}"
    exit 1
fi
NODE_VERSION=$(node -v)
echo -e "${GREEN}✓ Node.js ${NODE_VERSION}${NC}"

# Check PostgreSQL
echo ""
echo "🗄️  Checking PostgreSQL..."
if ! command -v psql &> /dev/null; then
    echo -e "${RED}PostgreSQL not found. Please install it${NC}"
    exit 1
fi
echo -e "${GREEN}✓ PostgreSQL installed${NC}"

# Check Git
echo ""
echo "📝 Checking Git..."
if ! command -v git &> /dev/null; then
    echo -e "${RED}Git not found. Please install it${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Git installed${NC}"

# Create project structure
echo ""
echo "📁 Creating project structure..."

# Create directories
mkdir -p contentflow/{backend,frontend,landing}
cd contentflow

# Create backend package.json
echo "📦 Setting up backend..."
cat > backend/package.json << 'EOF'
{
  "name": "contentflow-backend",
  "version": "1.0.0",
  "description": "ContentFlow API",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "@anthropic-ai/sdk": "^0.24.0",
    "bcryptjs": "^2.4.3",
    "cors": "^2.8.5",
    "dotenv": "^16.0.3",
    "express": "^4.18.2",
    "jsonwebtoken": "^9.0.0",
    "pg": "^8.10.0",
    "stripe": "^12.0.0"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}
EOF

# Create backend .env template
cat > backend/.env.example << 'EOF'
# Anthropic API
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxx

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/contentflow

# JWT Secret
JWT_SECRET=your-super-secret-key-here-change-this

# Environment
NODE_ENV=development
PORT=5000

# Stripe (optional)
STRIPE_SECRET_KEY=sk_test_xxxxxxxxxxxxx
STRIPE_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxx
STRIPE_STARTER_PRICE_ID=price_xxxxxxxxxxxxx
STRIPE_PRO_PRICE_ID=price_xxxxxxxxxxxxx
STRIPE_AGENCY_PRICE_ID=price_xxxxxxxxxxxxx

# Frontend URL
FRONTEND_URL=http://localhost:3000
EOF

cp backend/.env.example backend/.env

echo -e "${GREEN}✓ Backend structure created${NC}"

# Install backend dependencies
echo ""
echo "⬇️  Installing backend dependencies (this may take a minute)..."
cd backend
npm install
cd ..
echo -e "${GREEN}✓ Backend dependencies installed${NC}"

# Create frontend .env
echo ""
echo "📦 Setting up frontend..."
cat > frontend/.env << 'EOF'
REACT_APP_API_URL=http://localhost:5000
EOF

echo -e "${GREEN}✓ Frontend structure created${NC}"

# Create .gitignore
cat > .gitignore << 'EOF'
node_modules/
.env
.env.local
.DS_Store
*.log
.vscode/
.idea/
dist/
build/
EOF

# Create README
cat > README.md << 'EOF'
# ContentFlow

AI-powered content generation platform for creators, consultants, and freelancers.

## Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL
- Git

### Setup

1. **Set up backend:**
```bash
cd backend
npm install
# Edit .env with your API keys
node server.js
```

2. **Set up database:**
```bash
createdb contentflow
# Run database setup (see Implementation-Guide.md)
```

3. **Set up frontend:**
```bash
# In a new terminal
cd frontend
npm install
npm start
```

4. **Access the app:**
- Frontend: http://localhost:3000
- API: http://localhost:5000

## Environment Variables

Create `.env` in backend/ with:
- ANTHROPIC_API_KEY (from console.anthropic.com)
- DATABASE_URL (PostgreSQL connection)
- JWT_SECRET (random string for auth)

## Deployment

See Implementation-Guide.md for detailed deployment instructions to Render and Vercel.

## Support

For issues, see the Troubleshooting section in Implementation-Guide.md
EOF

echo ""
echo "✅ Setup complete!"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo ""
echo "1. Get Anthropic API key:"
echo "   → Go to console.anthropic.com"
echo "   → Create an API key"
echo "   → Add to backend/.env"
echo ""
echo "2. Set up PostgreSQL database:"
echo "   → Follow 'Step 4' in Implementation-Guide.md"
echo ""
echo "3. Start development:"
echo "   → Terminal 1: cd backend && npm start"
echo "   → Terminal 2: cd frontend && npm install && npm start"
echo ""
echo "4. Create React app for frontend:"
echo "   → cd frontend && npx create-react-app . --template minimal"
echo ""
echo -e "${GREEN}Happy building! 🚀${NC}"
EOF
