import React, { useState } from 'react';
import { Copy, Download, Sparkles, Settings, Library, ArrowRight, CheckCircle } from 'lucide-react';

const CreatorPlatform = () => {
  const [activeTab, setActiveTab] = useState('generator');
  const [userProfile, setUserProfile] = useState({
    name: 'Alex Chen',
    expertise: 'Product Strategy & Growth Marketing',
    bio: 'Helping startups scale from 0 to 100M users',
    tone: 'conversational',
    audience: 'startup founders and product managers',
    style: 'practical, story-driven, data-backed'
  });

  const [contentType, setContentType] = useState('linkedin');
  const [generatedContent, setGeneratedContent] = useState(null);
  const [loading, setLoading] = useState(false);
  const [contentHistory, setContentHistory] = useState([
    {
      id: 1,
      type: 'linkedin',
      title: 'The 80/20 of Product Launches',
      content: 'Most teams spend 80% of their time on 20% of features...',
      date: '2024-05-15',
      saved: true
    },
    {
      id: 2,
      type: 'blog',
      title: 'How We Grew to 50k Users in 6 Months',
      content: 'When we started this product, we had no idea what we were doing...',
      date: '2024-05-12',
      saved: true
    }
  ]);

  const [showSettings, setShowSettings] = useState(false);
  const [copiedId, setCopiedId] = useState(null);

  const generateContent = async () => {
    setLoading(true);
    
    try {
      const prompts = {
        linkedin: `Generate a compelling LinkedIn post for ${userProfile.name} about "${contentType}" topic. 
        Expertise: ${userProfile.expertise}
        Bio: ${userProfile.bio}
        Tone: ${userProfile.tone}
        Audience: ${userProfile.audience}
        Style: ${userProfile.style}
        Make it engaging, with a hook at the start, 3-4 key insights, and a call-to-action. Include relevant emojis. Keep it 150-250 words.`,
        
        blog: `Generate a compelling blog post outline and introduction for ${userProfile.name}. 
        Topic: "${userProfile.expertise} insights for ${userProfile.audience}"
        Expertise: ${userProfile.expertise}
        Style: ${userProfile.style}
        Create a catchy title, compelling introduction (100-150 words), and a 5-point outline. 
        Make it feel authentic to their voice and practical for their audience.`,
        
        newsletter: `Generate a weekly newsletter section for ${userProfile.name}. 
        Subject line idea and opening hook for an email to: ${userProfile.audience}
        Main topic: A recent insight about ${userProfile.expertise}
        Tone: ${userProfile.tone}
        Style: ${userProfile.style}
        Include subject line, engaging opening (2-3 sentences), 2 actionable insights, and a soft CTA.`,
        
        video: `Generate 3 viral video ideas for ${userProfile.name} in their niche.
        Expertise: ${userProfile.expertise}
        Audience: ${userProfile.audience}
        Style: ${userProfile.style}
        For each idea, provide: Title, Hook (first 10 seconds), Main talking points (3-4 points), and Ending/CTA.
        Make them short-form video ready (60-90 seconds)`,
        
        twitter: `Generate 5 tweet ideas for ${userProfile.name}.
        Expertise: ${userProfile.expertise}
        Audience: ${userProfile.audience}
        Tone: ${userProfile.tone}
        Mix of: hot takes, practical tips, behind-the-scenes, questions for engagement, and insights.
        Each tweet 280 characters max, with relevant hashtags or emojis.`
      };

      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [
            { role: 'user', content: prompts[contentType] }
          ],
        })
      });

      const data = await response.json();
      const content = data.content[0].text;
      
      const newContent = {
        id: contentHistory.length + 1,
        type: contentType,
        title: `Generated ${contentType.charAt(0).toUpperCase() + contentType.slice(1)}`,
        content: content,
        date: new Date().toISOString().split('T')[0],
        saved: false
      };

      setGeneratedContent(newContent);
    } catch (error) {
      console.error('Error generating content:', error);
      setGeneratedContent({
        id: Date.now(),
        type: contentType,
        title: `Generated ${contentType.charAt(0).toUpperCase() + contentType.slice(1)}`,
        content: `[Sample generated content would appear here]\n\nThis is where your AI-generated ${contentType} content would appear based on your expertise and voice preferences.`,
        date: new Date().toISOString().split('T')[0],
        saved: false
      });
    }
    
    setLoading(false);
  };

  const saveContent = () => {
    if (generatedContent) {
      const saved = { ...generatedContent, saved: true };
      setContentHistory([saved, ...contentHistory]);
      setGeneratedContent(null);
    }
  };

  const copyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const downloadContent = (content) => {
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', 'content.txt');
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900" style={{
      backgroundImage: 'radial-gradient(at 20% 50%, rgba(139, 92, 246, 0.1) 0px, transparent 50%), radial-gradient(at 80% 80%, rgba(59, 130, 246, 0.1) 0px, transparent 50%)'
    }}>
      {/* Header */}
      <header className="border-b border-purple-800/30 bg-black/40 backdrop-blur-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-blue-500 rounded-xl flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">ContentFlow</h1>
              <p className="text-xs text-purple-300">AI for Authentic Creators</p>
            </div>
          </div>
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 hover:bg-purple-800/30 rounded-lg transition-all"
          >
            <Settings className="w-5 h-5 text-purple-300" />
          </button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Settings Panel */}
        {showSettings && (
          <div className="mb-8 p-6 bg-gradient-to-r from-purple-900/40 to-blue-900/40 border border-purple-800/50 rounded-xl backdrop-blur-sm">
            <h2 className="text-lg font-bold text-white mb-4">Your Creator Profile</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-purple-300 mb-2">Name</label>
                <input
                  type="text"
                  value={userProfile.name}
                  onChange={(e) => setUserProfile({...userProfile, name: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-800/50 border border-purple-700/50 rounded-lg text-white focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <label className="block text-sm text-purple-300 mb-2">Expertise</label>
                <input
                  type="text"
                  value={userProfile.expertise}
                  onChange={(e) => setUserProfile({...userProfile, expertise: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-800/50 border border-purple-700/50 rounded-lg text-white focus:outline-none focus:border-purple-500"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm text-purple-300 mb-2">Bio / Description</label>
                <textarea
                  value={userProfile.bio}
                  onChange={(e) => setUserProfile({...userProfile, bio: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-800/50 border border-purple-700/50 rounded-lg text-white focus:outline-none focus:border-purple-500 h-20"
                />
              </div>
              <div>
                <label className="block text-sm text-purple-300 mb-2">Tone</label>
                <select
                  value={userProfile.tone}
                  onChange={(e) => setUserProfile({...userProfile, tone: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-800/50 border border-purple-700/50 rounded-lg text-white focus:outline-none focus:border-purple-500"
                >
                  <option>conversational</option>
                  <option>professional</option>
                  <option>educational</option>
                  <option>humorous</option>
                  <option>inspirational</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-purple-300 mb-2">Target Audience</label>
                <input
                  type="text"
                  value={userProfile.audience}
                  onChange={(e) => setUserProfile({...userProfile, audience: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-800/50 border border-purple-700/50 rounded-lg text-white focus:outline-none focus:border-purple-500"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm text-purple-300 mb-2">Writing Style</label>
                <input
                  type="text"
                  value={userProfile.style}
                  onChange={(e) => setUserProfile({...userProfile, style: e.target.value})}
                  placeholder="e.g., practical, story-driven, data-backed"
                  className="w-full px-4 py-2 bg-slate-800/50 border border-purple-700/50 rounded-lg text-white focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Generator */}
          <div className="lg:col-span-2">
            <div className="bg-gradient-to-br from-slate-800/60 to-slate-900/60 border border-purple-800/30 rounded-2xl p-8 backdrop-blur-sm">
              <h2 className="text-2xl font-bold text-white mb-2">Generate Content</h2>
              <p className="text-purple-300 mb-6">In your authentic voice</p>

              {/* Content Type Selector */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
                {[
                  { id: 'linkedin', label: 'LinkedIn', icon: '💼' },
                  { id: 'blog', label: 'Blog Post', icon: '📝' },
                  { id: 'newsletter', label: 'Newsletter', icon: '📧' },
                  { id: 'video', label: 'Video Ideas', icon: '🎬' },
                  { id: 'twitter', label: 'Tweets', icon: '𝕏' }
                ].map(type => (
                  <button
                    key={type.id}
                    onClick={() => setContentType(type.id)}
                    className={`p-3 rounded-lg font-medium transition-all ${
                      contentType === type.id
                        ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg shadow-purple-500/50'
                        : 'bg-slate-700/50 text-purple-300 hover:bg-slate-600/50'
                    }`}
                  >
                    <div className="text-lg mb-1">{type.icon}</div>
                    <div className="text-xs">{type.label}</div>
                  </button>
                ))}
              </div>

              {/* Generate Button */}
              <button
                onClick={generateContent}
                disabled={loading}
                className="w-full px-6 py-4 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 disabled:from-slate-600 disabled:to-slate-700 text-white font-bold rounded-xl transition-all transform hover:scale-[1.02] shadow-lg shadow-purple-500/50 mb-6 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-r-transparent rounded-full animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    Generate {contentType.charAt(0).toUpperCase() + contentType.slice(1)}
                  </>
                )}
              </button>

              {/* Generated Content Display */}
              {generatedContent && (
                <div className="p-6 bg-gradient-to-br from-purple-900/30 to-blue-900/30 border border-purple-700/50 rounded-xl">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-lg font-bold text-white">Generated Content</h3>
                    <button
                      onClick={saveContent}
                      className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-lg hover:from-emerald-600 hover:to-teal-600 transition-all text-sm font-medium"
                    >
                      Save to Library
                    </button>
                  </div>
                  <div className="prose prose-invert max-w-none mb-4">
                    <div className="text-purple-200 whitespace-pre-wrap text-sm leading-relaxed max-h-96 overflow-y-auto">
                      {generatedContent.content}
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => copyToClipboard(generatedContent.content, generatedContent.id)}
                      className="flex-1 px-4 py-2 bg-slate-700/50 hover:bg-slate-600/50 text-purple-300 rounded-lg transition-all flex items-center justify-center gap-2"
                    >
                      {copiedId === generatedContent.id ? (
                        <>
                          <CheckCircle className="w-4 h-4" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          Copy
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => downloadContent(generatedContent.content)}
                      className="flex-1 px-4 py-2 bg-slate-700/50 hover:bg-slate-600/50 text-purple-300 rounded-lg transition-all flex items-center justify-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      Download
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Content Library Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gradient-to-br from-slate-800/60 to-slate-900/60 border border-purple-800/30 rounded-2xl p-6 backdrop-blur-sm sticky top-24">
              <div className="flex items-center gap-2 mb-4">
                <Library className="w-5 h-5 text-purple-400" />
                <h3 className="text-lg font-bold text-white">Content Library</h3>
              </div>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {contentHistory.length === 0 ? (
                  <p className="text-slate-400 text-sm">Your saved content will appear here</p>
                ) : (
                  contentHistory.map(item => (
                    <div
                      key={item.id}
                      className="p-3 bg-slate-700/50 rounded-lg hover:bg-slate-600/50 transition-all cursor-pointer border border-slate-600/30"
                    >
                      <div className="flex items-start justify-between mb-1">
                        <span className="text-xs font-medium text-purple-400 uppercase">
                          {item.type}
                        </span>
                        <span className="text-xs text-slate-400">{item.date}</span>
                      </div>
                      <p className="text-sm text-white font-medium line-clamp-2">
                        {item.title}
                      </p>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                        {item.content.substring(0, 60)}...
                      </p>
                      <button
                        onClick={() => copyToClipboard(item.content, item.id)}
                        className="mt-2 w-full px-2 py-1 bg-slate-800/50 hover:bg-slate-700 rounded text-xs text-purple-300 transition-all"
                      >
                        {copiedId === item.id ? 'Copied!' : 'Copy'}
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreatorPlatform;